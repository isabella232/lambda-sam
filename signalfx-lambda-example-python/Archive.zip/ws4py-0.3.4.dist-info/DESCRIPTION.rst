WebSocket client and server library for Python 2 and 3 as well as PyPy


