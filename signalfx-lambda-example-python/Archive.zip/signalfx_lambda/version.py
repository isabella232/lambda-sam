# Copyright (C) 2017 SignalFx, Inc. All rights reserved.

name = 'signalfx_lambda'
version = '0.0.2'

user_agent = 'signalfx_lambda/' + version