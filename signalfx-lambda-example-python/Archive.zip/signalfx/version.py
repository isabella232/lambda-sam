# Copyright (C) 2015-2016 SignalFx, Inc. All rights reserved.

name = 'signalfx'
version = '1.0.16'
